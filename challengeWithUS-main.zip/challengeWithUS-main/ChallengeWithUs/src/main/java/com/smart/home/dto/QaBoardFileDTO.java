package com.smart.home.dto;

import lombok.Data;

@Data
public class QaBoardFileDTO {
	private int qafileNo;//�Ϸù�ȣ
	private int qaNo;//���۹�ȣ
	private String qafileName;
	
}
