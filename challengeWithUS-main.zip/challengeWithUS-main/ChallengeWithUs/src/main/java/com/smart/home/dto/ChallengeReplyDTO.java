package com.smart.home.dto;

import lombok.Data;

@Data
public class ChallengeReplyDTO {
	private int chalcommentNo;
	private int chalNo;
	private String memberId;
	private String chalcommentContent;
	private String chalcommentDate;
}
