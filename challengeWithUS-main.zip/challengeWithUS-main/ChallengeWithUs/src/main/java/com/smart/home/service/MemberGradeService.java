//package com.smart.home.service;
//
//import org.apache.ibatis.annotations.Param;
//
//import com.smart.home.dto.MemberGradeDTO;
//
//public interface MemberGradeService {
//
//	MemberGradeDTO getMemberGrade(@Param("memberId") String memberId);
//
//}
