//package com.smart.home.service;
//
//import com.smart.home.dto.MemberGradeDTO;
//
//public class MemberGradeServiceImpl implements MemberGradeService{
//
//	@Override
//	public MemberGradeDTO getMemberGrade(String memberId) {
//		return null;
//	}
//
//}
