package com.javachip.myapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/register")
public class RegisterController {
	@GetMapping("/regPage")
	public String regPage() {
		return "register/registerJoin";
	}
	
	@GetMapping("/login")
	public String login() {
		return "register/LoginPage";
	}
	
	@GetMapping("/FindID")
	public String FindID() {
		return "register/FindID";
	}
	
	@GetMapping("/pwSearch")
	public String pwSearch() {
		return "register/pwSearch";
	}
}
